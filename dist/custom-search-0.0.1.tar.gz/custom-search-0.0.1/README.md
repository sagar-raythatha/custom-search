# Custom Search Package

This package is designed to search keywords within the text provided.

The basic inspiration to build this package is, twitter standard streaming api doesn't provide matching rules in the result.

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.